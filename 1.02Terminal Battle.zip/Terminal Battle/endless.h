#ifndef endless
#define endless
//player information
struct Player{
     char name[100];
     
     int HP;
     int MP;
     int experience;
} Pl;
//common enemy information
struct Enemy
{
     char name[100];
     
     int HP;
     
     int burned;
     int frozen;
     int shocked;
     int confused;
} En;
struct Magic
{
     int firagaMP;
     int firagaMiss;
     int burnChance;
     
     int blizzagaMP;
     int blizzagaMiss;
     int freezeChance;
     
     int thundagaMP;
     int thundagaMiss;
     int shockChance;
     
     int aerogaMP;
     int aerogaMiss;
     int confuseChance;
     
     int curaga;
} Ma;
//amount of each type of potion
struct Items
{
     int potionC;
     int potionHeal; 
     int etherC;
     int etherRest;
} It;
struct Attacks
{
    int lightBlock;
    int heavyBlock;
    int luckyMP;
    int luckyBlock;
    int sonicMP;
    int arsMP;
    int arsBlock;
    int zanteMP;
    int zanteBlock;
    int zanteSuc;
} At;
void initialize()
{
        snprintf(Pl.name, sizeof(Pl.name), "Player");
        snprintf(En.name, sizeof(Pl.name), "DEFAULT");
        Pl.HP = 750;
        Pl.MP = 100;
        En.HP = 1000;
        It.potionC = 3; 
        It.etherC = 2,
        It.potionHeal = 250,
        It.etherRest = 40;
        
        Ma.firagaMP = 5;
        Ma.burnChance = 15;
        Ma.firagaMiss = 0;
        Ma.blizzagaMP = 10;
        Ma.blizzagaMiss = 15;
        Ma.freezeChance = 15;
        Ma.thundagaMP = 30;
        Ma.shockChance = 30;
        Ma.thundagaMiss = 45;
        Ma.aerogaMP = 20;
        Ma.aerogaMiss = 25;
        Ma.confuseChance = 20;
        
        At.lightBlock = 75;
        At.heavyBlock = 25;
        At.luckyMP = 15;
        At.luckyBlock = 33;
        At.sonicMP = 40;
        At.arsMP = 90;
        At.arsBlock = 90;
        At.zanteMP = 1;
        At.zanteBlock = 0;
        At.zanteSuc = 3;
        
        En.frozen = 0;
        En.burned = 0;
        En.shocked = 0;
        En.confused = 0;
}
#endif