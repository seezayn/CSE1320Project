#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include "options.h"
#include "endless.h"
//(rand()%100) + 1; is used throughout the program, this is range 1 - 100 (Inclusive)
void enemyTurn(int *blocked)
{
    int enemyBurn = 0;
    int enemyConfuseChance = 0;
    int confusedDamage = 0;
    int totalBlockDamage = 0;
    int totalConfuseDamage = 0; //all these are used later in the function
    if (En.burned == 1)
    {
        enemyBurn = (rand() % 50) + 25;
    }
    if (En.HP <= 0)
    {
        return;
    }
    else
    {
        if (En.frozen <= 0)
        {
            int enemyAttack = (rand() % 100) + 1;
            if (En.confused == 1)
            {
                enemyConfuseChance = (rand() % 100) + 1;
            }
            if (En.shocked == 1)
            {
                int furtherMiss = (rand() % 100) + 1;
                if (furtherMiss > 70)   //This is a 30% chance that they will miss due to shock
                {
                    printf("%s couldn't attack due to being shocked!\n", En.name);
                    enemyAttack = 0;
                }
            }
            if (enemyAttack > 0 && enemyAttack <= 40)
            {   //just when we figured out a solution for enemy name, now we need to find enemy attack names ;^;
                int enemyDamage = (rand() % 75) + 50;
                printf("%s used Dark Firaga and dealt %d Damage!\n", En.name, enemyDamage);
                if (*blocked == 1)
                {
                    double blockedDamage = (rand() % 40);
                    blockedDamage *= 0.01;
                    totalBlockDamage = enemyDamage - enemyDamage*blockedDamage;
                    enemyDamage = enemyDamage * blockedDamage;
                    printf("Blocked %d Damage!\n", totalBlockDamage);
                }
                if (enemyConfuseChance > 50)
                {
                    double confusedDamage = (rand() % 25) + 25;
                    confusedDamage *= 0.01;
                    En.HP -= enemyDamage * confusedDamage;
                    printf("%s dealt %.0f damage to themselves in confusion!\n", En.name, enemyDamage * confusedDamage);
                }
                Pl.HP -= enemyDamage;
                En.HP -= enemyBurn;
            }
            else if (enemyAttack > 40 && enemyAttack <= 70)
            {
                int enemyDamage = (rand() % 125) + 100;
                printf("%s used Dark Break and dealt %d Damage!\n", En.name,enemyDamage);
                 if (*blocked == 1)
                {
                    double blockedDamage = (rand() % 40);
                    blockedDamage *= 0.01;
                    totalBlockDamage = enemyDamage - enemyDamage*blockedDamage;
                    enemyDamage = enemyDamage * blockedDamage;
                    printf("Blocked %d Damage!\n", totalBlockDamage);
                }
                if (enemyConfuseChance > 50)
                {
                    double confusedDamage = (rand() % 25) + 25;
                    confusedDamage *= 0.01;
                    En.HP -= enemyDamage * confusedDamage;
                    printf("%s dealt %.0f damage to themselves in confusion!\n", En.name, enemyDamage * confusedDamage);
                }
                Pl.HP -= enemyDamage;
                En.HP -= enemyBurn;
            }
            else if (enemyAttack > 70 && enemyAttack <=85)
            {
                int enemyDamage = (rand() % 175) + 175;
                printf("%s used Dark Aura and dealt %d Damage!\n", En.name, enemyDamage);
                 if (*blocked == 1)
                {
                    double blockedDamage = (rand() % 40);
                    blockedDamage *= 0.01;
                    totalBlockDamage = enemyDamage - enemyDamage*blockedDamage;
                    enemyDamage = enemyDamage * blockedDamage;
                    printf("Blocked %d Damage!\n", totalBlockDamage);
                }
                if (enemyConfuseChance > 50)
                {
                    double confusedDamage = (rand() % 25) + 25;
                    confusedDamage *= 0.01;
                    En.HP -= enemyDamage * confusedDamage;
                    printf("%s dealt %.0f damage to themselves in confusion!\n", En.name, enemyDamage * confusedDamage);
                }
                Pl.HP -= enemyDamage;
                En.HP -= enemyBurn;
            }
            else if (enemyAttack > 85)
            {
            printf("%s went for an attack but missed!\n", En.name);
            En.HP -= enemyBurn;
            }
        }
        else
        {
            printf("%s is frozen solid for %d more turns!\n", En.name, En.frozen);
            En.frozen -= 1;
        }
    }
    if (En.burned == 1)
    {
        printf("%s took %d additional burn damage\n", En.name, enemyBurn);
    }
}
void specialAttacks(int *attackChoice, int *blocked, int *maxPlayerHP, int *maxPlayerMP)
{
    int specialChoice = 0;
    printf("\n\n\n");
    do
    {
    printf("Special Attacks:\n\t\t---Current MP: %d---\n", Pl.MP);
    printf("[1] Lucky Strike (Low Damage, HP and MP restoration chance, %d%% Block Rate, %d MP)\n", At.luckyBlock, At.luckyMP);
    printf("[2] Sonic Blade (Moderate Damage, skips enemy turn, %d MP)\n", At.sonicMP);
    printf("[3] Ars Arcanum (Massive Damage, %d%% Block Rate, %d MP)\n", At.arsBlock, At.arsMP);
    printf("[4] Zantesuken (Super small damage, %d%% Chance for instant death, %d%% Block Rate, %d MP)\n", At.zanteSuc, At.zanteBlock, At.zanteMP);
    printf("[5] Back\n");
    scanf("%d", &specialChoice);
    if (specialChoice == 1)
    {
        if (Pl.MP >= At.luckyMP)
        {
            *attackChoice = 4;
            Pl.MP -= At.luckyMP;
            int luckyAttackDamage = (rand() % 50) + 60;
            int luckyBlock = (rand()%100) + 1;
            if (luckyBlock > 100 - At.luckyBlock)
            {
                *blocked = 1;
            }
            En.HP -= luckyAttackDamage;
            printf("Dealt %d damage using Lucky Strike!\n", luckyAttackDamage);
            int restoreHPMP = (rand() % 100) + 1;
            if (restoreHPMP <= 25)
            {
                int restoreamoHP = (rand() % 150) + 50;
                Pl.HP += restoreamoHP;
                if (Pl.HP > *maxPlayerHP)
                {
                     Pl.HP = *maxPlayerHP;
                }
                printf("Restored %d HP!\n",restoreamoHP);
            }
            else if (restoreHPMP > 25 && restoreHPMP <= 50)
            {
                int restoreamoMP = (rand() % 15) + 25;
                Pl.MP += restoreamoMP;
                if (Pl.MP > *maxPlayerMP)
                {
                    Pl.MP = *maxPlayerMP;
                }
                printf("Restored %d MP!\n", restoreamoMP);
            }
            else if (restoreHPMP > 50 && restoreHPMP <= 75)
            {
                int restoreamoHP = (rand() % 150) + 50;
                int restoreamoMP = (rand() % 15) + 25;
                Pl.HP += restoreamoHP;
                Pl.MP += restoreamoMP;
                if (Pl.HP > *maxPlayerHP)
                {
                    Pl.HP = *maxPlayerHP;
                }
                if (Pl.MP > *maxPlayerMP)
                {
                    Pl.MP = *maxPlayerMP;
                }
                printf("Restored %d HP and %d MP!\n", restoreamoHP, restoreamoMP);
            }
            else
            {
                printf("Restored neither HP nor MP...\n");
            }
            enemyTurn(blocked);
        }
        else
        {
            printf("You don't have enough MP to use Lucky Strike!\n");
        }
    }
    else if (specialChoice == 2)
    {
        if (Pl.MP >= At.sonicMP)
        {
            *attackChoice = 4;
            Pl.MP -= At.sonicMP;
            int sonicBlade = (rand() % 200) + 100;
            En.HP -= sonicBlade;
            printf("Dealt %d damage using Sonic Blade!\n", sonicBlade);
            printf("%s's turn was skipped!\n", En.name);
        }
        else
        {
            printf("You don't have enough MP to use Sonic Blade!\n");
        }
    }
    else if (specialChoice == 3)
    {
        if (Pl.MP >= At.arsMP)
        {
            *attackChoice = 4;
            Pl.MP -= At.arsMP;
            int arsArcanum = (rand() % 400) + 300;
            int arsBlock = (rand() % 100) + 1;
            En.HP -= arsArcanum;
            printf("Dealt %d damage using Ars Arcanum!\n", arsArcanum);
            if (arsBlock > 100 - At.arsBlock)
            {
                *blocked = 1;
            }
            enemyTurn(blocked);
        }
        else
        {
            printf("You don't have enough MP to use Ars Arcanum!\n");
        }
    }
    else if (specialChoice == 4)
    {
        if (Pl.MP >= At.zanteMP)
            {
            *attackChoice = 4;
            Pl.MP -= At.zanteMP;
            int zantChance = (rand() % 100) + 1;
            int zantDamage = (rand() % 2) + 1;
            int zantBlock = (rand()% 100)+ 1;
            if (zantBlock > 100 - At.zanteBlock)
            {
                *blocked = 1;
            }
            if (zantChance > 100 - At.zanteSuc)
            {
                printf("Zantesuken succeded, dealt %d damage!!\n", En.HP);
                En.HP = 0;
                enemyTurn(blocked);
            }
            else
            {
                En.HP -= zantDamage;
                printf("Dealt %d damage using Zantesuken...\n", zantDamage);
                enemyTurn(blocked);
            }
        }
        else
        {
            printf("You don't have enough MP to use Zantesuken!\n");
        }
    }
    else if (specialChoice == 5)
    {
        printf("\n\n\n");
        continue;
    }
    else
    {
        printf("\n\n\n");
        printf("Please enter a different number.\n");
    }
    } while (specialChoice < 1 || specialChoice > 5);
}
void Attack(int *blocked, int *maxPlayerHP, int *maxPlayerMP)
{
    int attackChoice = 0;
    do
    {
        printf("\n\n\n");
        printf("Attacks Choices:\n");
        printf("[1] Light Attack (Low Damage, %d%% Block Rate)\n", At.lightBlock);
        printf("[2] Heavy Attack (High Damage, %d%% Block Rate)\n", At.heavyBlock);
        printf("[3] Special Attacks\n");
        printf("[4] Back\n");
        scanf("%d", &attackChoice);
        if (attackChoice == 1)
        {
            int lightAttackDamage = (rand() % 50) + 80;
            int lightBlock = (rand()%100)+1;
            if (lightBlock > 100 - At.lightBlock)
            {
                *blocked = 1;
            }
            En.HP -= lightAttackDamage;
            printf("Dealt %d damage using a light attack!\n", lightAttackDamage);
            enemyTurn(blocked);
        }
        else if (attackChoice == 2)
        {
            int heavyAttackDamage = (rand() % 60) + 150;
            int heavyBlock = (rand()%100)+1;
            if (heavyBlock > 100 - At.heavyBlock)
            {
                *blocked = 1;
            }
            En.HP -= heavyAttackDamage;
            printf("Dealt %d damage using a heavy attack!\n", heavyAttackDamage);
            enemyTurn(blocked);
        }
        else if (attackChoice == 3)
        {
            attackChoice = -404;
            specialAttacks(&attackChoice,blocked, maxPlayerHP, maxPlayerMP);
        }
        else if (attackChoice == 4)
        {
            printf("\n\n\n");
            continue;
        }
        else
        {
            printf("Please enter a different number.\n");
        }
        if (attackChoice == 4)
        {
            printf("\n\n\n");
            continue;
        }
    } while (attackChoice < 1 || attackChoice > 4);
}
void Magic(int *blocked)
{
    int magicMenuChoice = 0;
    printf("\n\n\n");
    do
        {
            printf("Magic Spells:\n\t\t---Current MP: %d---\n", Pl.MP);
            printf("[1] Firaga\t(Low Damage, %d%% Chance to Burn, %d%% Chance to miss, %dMP)\n", Ma.burnChance, Ma.firagaMiss, Ma.firagaMP);
            printf("[2] Blizzaga\t(Medium Damage, %d%% Chance to Freeze, %d%% Chance to miss, %dMP)\n", Ma.freezeChance, Ma.blizzagaMiss, Ma.blizzagaMP);
            printf("[3] Thundaga\t(Large Damage, %d%% Chance to Shock, %d%% Chance to miss, %dMP)\n", Ma.shockChance, Ma.thundagaMiss, Ma.thundagaMP);
            printf("[4] Aeroga\t(Medium Damage, %d%% Chance to Confuse, %d%% Chance to miss, %dMP)\n[5] Back\n", Ma.confuseChance, Ma.aerogaMiss, Ma.aerogaMP);
            scanf("%d", &magicMenuChoice);
            if (magicMenuChoice == 1)
            {
                if (Pl.MP >= Ma.firagaMP)
                {
                    Pl.MP -= Ma.firagaMP;
                    int firagaChance = (rand() % 100) + 1;
                    if (firagaChance <= 100- Ma.firagaMiss)
                    {
                        int firagaDamage = (rand() % 121) + 60;
                        int burnChance = (rand() % 100) + 1;
                        printf("\nDealt %d Damage using Firaga!\n", firagaDamage);
                        En.HP -= firagaDamage;
                        if (En.frozen > 0)
                        {
                            printf("Firaga thawed %s out...\n", En.name);
                            En.frozen = 0;
                        }
                        else if (burnChance > 100 - Ma.burnChance)
                        {
                            En.burned = 1;
                            printf("%s has been burned!\n", En.name);
                        }
                        enemyTurn(blocked);
                    }
                    else
                    {
                        printf("Firaga missed!\n");
                        enemyTurn(blocked);
                    }
                }
                else
                {
                    printf("You don't have enough MP to use Firaga!\n");
                }
            }
            else if (magicMenuChoice == 2)
            {
                if (Pl.MP >= Ma.blizzagaMP)
                {
                    Pl.MP -= Ma.blizzagaMP;
                    int blizzagaChance = (rand() % 100) + 1;
                    if (blizzagaChance <= 100 - Ma.blizzagaMiss)
                    {
                        int blizzagaDamage = (rand() % 126) + 125;
                        int freezeChance = (rand() % 100) + 1;
                        if (freezeChance > 100 - Ma.freezeChance)
                        {
                            printf("\nDealt %d Damage using Blizzaga!\n", blizzagaDamage);
                            printf("%s has been frozen!\n", En.name);
                            En.frozen = (rand() % 4) + 1;
                            En.HP -= blizzagaDamage;
                            enemyTurn(blocked);
                        }
                        else
                        {
                            printf("\nDealt %d Damage using Blizzaga!\n", blizzagaDamage);
                            En.HP -= blizzagaDamage;
                            enemyTurn(blocked);
                        }
                    }
                    else
                    {
                        printf("Blizzaga Missed!\n");
                        enemyTurn(blocked);
                    }
                }
                else
                {
                    printf("You don't have enough MP to use Blizzaga!\n");
                }
            }
            else if (magicMenuChoice == 3)
            {
                if (Pl.MP >= Ma.thundagaMP)
                {
                    Pl.MP -= Ma.thundagaMP;
                    int thundagaChance = (rand() % 100) + 1;
                    if (thundagaChance <= 100 - Ma.thundagaMiss)
                    {
                        int thundagaDamage = (rand() % 251) + 320;
                        int shockChance = (rand() % 100 + 1);
                        if (shockChance > 100 - Ma.shockChance)
                        {
                            printf("\nDealt %d Damage using Thundaga!\n", thundagaDamage);
                            printf("%s has been shocked! %s will now miss attacks more frequently!\n", En.name, En.name);
                            En.shocked = 1;
                            En.HP -= thundagaDamage;
                            enemyTurn(blocked);
                        }
                        else
                        {
                            printf("\nDealt %d Damage using Thundaga!\n", thundagaDamage);
                            En.HP -= thundagaDamage;
                            enemyTurn(blocked);
                        }
                    }
                    else
                    {
                        printf("Thundaga missed!\n");
                        enemyTurn(blocked);
                    }
                }
                else
                {
                    printf("You don't have enough MP to use Thundaga!\n");
                }
            }
            else if (magicMenuChoice == 4)
            {
                if (Pl.MP >= Ma.aerogaMP)
                {
                    Pl.MP -= Ma.aerogaMP;
                    int aerogaChance = (rand() % 100) + 1;
                    if (aerogaChance <= 100 - Ma.aerogaMiss)
                    {
                        int confuseChance = (rand() % 100) + 1;
                        int aerogaDamage = (rand() % 200) + 175;
                        printf("Dealt %d damage using Aeroga!\n", aerogaDamage);
                        En.HP -= aerogaDamage;
                        if (confuseChance > 100 - Ma.confuseChance)
                        {
                            printf("%s is now confused and may hit themselves!\n",En.name);
                            En.confused = 1;
                            enemyTurn(blocked);
                        }
                        else
                        {
                        enemyTurn(blocked);
                        }
                    }
                    else
                    {
                        printf("Aeroga Missed!\n");
                        enemyTurn(blocked);
                    }
                }
                else
                {
                    printf("You don't have enough MP to use Aeroga!\n");
                }
            }
            else if (magicMenuChoice == 5)
            {
                printf("\n\n\n");
            }
            else
            {
                printf("Please enter a different number.\n");
            }
        } while (magicMenuChoice < 1 || magicMenuChoice > 5);
}
void Items(int *potionUsed, int *maxPlayerHP, int *etherUsed, int *maxPlayerMP, int *blocked)
{
    int itemMenuChoice = 0;
    printf("\n\n\n");
    do
    {
        printf("Items:\n[1] Potion (Heals %dHP) x %d\n",It.potionHeal, It.potionC);
        printf("[2] Ether (Restores %dMP) x %d\n", It.etherRest, It.etherC);
        printf("[3] Back\n");
        scanf("%d", &itemMenuChoice);
        if (itemMenuChoice == 1)
        {
            if (It.potionC > 0 && Pl.HP < *maxPlayerHP)
            {
                Pl.HP += It.potionHeal;
                if (Pl.HP > *maxPlayerHP)
                {
                    Pl.HP = *maxPlayerHP;
                }
                printf("Healed %dHP!\n", It.potionHeal);
                It.potionC -= 1;
                *potionUsed += 1;
                enemyTurn(blocked);
            }
            else if (Pl.HP == *maxPlayerHP)
            {
                printf("Using a potion now would have no effect!\n");
            }
            else
            {
                printf("You're all out of potions!\n");
            }
        }
        else if (itemMenuChoice == 2)
        {
            if (It.etherC > 0 && Pl.MP < *maxPlayerMP)
            {
                Pl.MP += It.etherRest;
                if (Pl.MP> *maxPlayerMP)
                {
                    Pl.MP = *maxPlayerMP;
                }
                printf("Restored %dMP!\n", It.etherRest);
                It.etherC -= 1;
                *etherUsed += 1;
                enemyTurn(blocked);
            }
            else if (Pl.MP == *maxPlayerMP)
            {
                printf("Using an ether now would have no effect!\n");
            }
            else
            {
                printf("You're all out of ethers!\n");
            }
        }
        else if (itemMenuChoice == 3)
        {
            printf("\n\n\n");
        }
        else
        {
            printf("Please enter a different number.\n");
        }
    } while (itemMenuChoice < 1 || itemMenuChoice > 3); 
}
void mainMenu(int *playing,int *modified, int *titleChoi)
{
    int maxPlayerHP = Pl.HP;
    int maxEnemyHP = En.HP;
    int maxPotionCount = It.potionC;
    int maxEtherCount = It.etherC;
    int maxPlayerMP = Pl.MP; //used for end-game statistics, might add more if we decide to track more
    int potionUsed = 0, etherUsed = 0, blocked = 0;
    do
    {
        blocked = 0;
        int menuChoice = 0;
        printf("%s's HP: %d\t%s's HP: %d\n", Pl.name, Pl.HP, En.name, En.HP);
        printf("[1] Attack\n");
        printf("[2] Magic Spells\n");
        printf("[3] Items\n");
        scanf("%d", &menuChoice);
        if (menuChoice == 1)
        {
            Attack(&blocked, &maxPlayerHP, &maxPlayerMP);
        }
        else if (menuChoice == 2)
        {
            Magic(&blocked);
        }
        else if (menuChoice == 3)
        {
            Items(&potionUsed, &maxPlayerHP, &etherUsed, &maxPlayerMP, &blocked);
        }
        else
        {
            printf("Please enter a different number.\n");
        }
    } while (Pl.HP > 0 && En.HP > 0);
    if (Pl.HP <= 0 && En.HP <= 0)
    {
        Pl.HP = 0;
        En.HP = 0;
        printf("The battle has ened in a draw!\n");
    }
    else if (Pl.HP <= 0)           
    {
        printf("You lost to %s...\n", En.name);
        Pl.HP = 0;
    }
    else if (En.HP <= 0)
    {
        printf("You have defeated %s!\n\n", En.name);
        Pl.experience = (rand() % 2000) + 1000;
        printf("You gained %d experience\n", Pl.experience);
        En.HP = 0;
    }
    else
    {
        printf("This message should never appear. If this appears, you found a bug!\n");        //gotta do something for this right? funsies
    }
    printf("Stats:\n%s's HP: %d/%d\t||\t%s's HP: %d/%d\n", Pl.name, Pl.HP, maxPlayerHP, En.name, En.HP, maxEnemyHP);
    printf("Potions Used: %d/%d\nEthers Used: %d/%d\n", potionUsed, maxPotionCount, etherUsed, maxEtherCount);
    printf("Remaining MP: %d/%d\n", Pl.MP, maxPlayerMP);
    int playChoice = 0;
    do
    {
        printf("\n\nPlay Again?\n[1] Yes\n[2] No\n");
        scanf("%d", &playChoice);
        if (playChoice == 1)
        {
            if (*modified == 1)
            {
                int saveChoice;
                do
                {
                    printf("\n\n\nIt appears you were using modified settings! Would you like to save them for the next battle?\n");
                    printf("[1] Yes\n[2] No\n");
                    scanf("%d", &saveChoice);
                    if (saveChoice == 1)
                    {
                        Pl.HP = maxPlayerHP;
                        Pl.MP = maxPlayerMP;    //all of these need to be returned to max or else one of these will be 0 (or both HPs or all 3)
                        En.HP = maxEnemyHP;      //others dont need this treatment as they dont change throughout the battle
                        *titleChoi = 0;
                    }
                    else if (saveChoice == 2)
                    {
                        *modified = 0;
                    }
                    else
                    {
                        printf("Please enter a different number.\n");
                    }
                } while (saveChoice < 1 || saveChoice > 2);
            }
            printf("Starting Terminal Battle Again!\n");
            *playing = 0;
            continue;
        }
        else if (playChoice == 2)
        {
            exit(1);
        }
        else
        {
            printf("Please enter a different number.\n");
        }
    } while (playChoice < 1 || playChoice > 2);
}
int main(void)
{
    int playing = 0;
    do
    {
        int modified = 0;       //used for if the player modified settings
        int titleChoi = 0;
        initialize();           //this is located in endless.h at the bottom
    //from testing, the values had to be set to 0 to prevent memory overflow (Specifically in blizzagaChance and potionCount, idk why those two specifically ~Roxie)
        srand(time(NULL)); //sets the seed for the random values based on time
        printf("---------------------------------\n");
        printf("|\tTERMINAL BATTLE\t\t|\n");
        printf("---------------------------------\n");
        do
        {
            En.burned = 0, En.frozen = 0, En.shocked = 0;
            printf("Select a choice! (Type the number corresponding to the option, then press enter)\n");
            printf("[1] Start Battle\n[2] Options\n[3] Exit\n"); //didnt separate this printf statement bc it was so small ~Roxie
            scanf("%d", &titleChoi);
            if (titleChoi == 1)             //we can do switch case if we want, but it doesn't matter
            {
                int nameChoi = 0;
                do
                {
                    printf("Would you like to name your opponent?\n");
                    printf("[1] Yes\n[2] Pick for me\n[3] Back to Title Screen\n");
                    scanf("%d", &nameChoi);
                    if (nameChoi == 1)
                    {
                        getchar();  //apparently this removes the newline character from the previous input (nameChoi??), don't understand it entirely yet
                        printf("Enter the name of your opponent: ");
                        fgets(En.name,sizeof(En.name), stdin);
                        En.name[strlen(En.name) - 1] = '\0';        //gotta remove the newline charater from THIS input now
                        mainMenu(&playing, &modified, &titleChoi);
                    }
                    else if (nameChoi == 2)
                    {
                        char nameLine[50];
                        FILE *names = fopen("names", "r+");
                        if (names == NULL)
                        {
                            printf("Failed to retrieve names. Aborting!");
                            exit (1);
                        }
                        int lineCount = 0;
                        while (fgets(nameLine, sizeof(nameLine), names))
                        {
                            lineCount++;
                        }
                        fseek(names,0,SEEK_SET);
                        int currentLine = 0;
                        int nameResu = (rand() % lineCount);
                        while (fgets(nameLine,sizeof(nameLine),names))
                        {
                            if (currentLine == nameResu)
                            {
                                nameLine[strcspn(nameLine, "\n")] = '\0';
                                strcpy(En.name, nameLine);
                                break;
                            }
                            currentLine++;
                        }
                        fclose(names);
                        printf("Starting the battle!\n\n");     //this thing was a mess, i hated it. any way to make this simpler?
                        mainMenu(&playing, &modified, &titleChoi);
                    }
                    else if (nameChoi == 3)
                    {
                        titleChoi = 0;
                        printf("\n\n\n");
                       continue; 
                    }
                    else
                    {
                        printf("Please enter a different number.\n");
                    }
                } while (nameChoi < 1 || nameChoi > 3);
            }
            else if (titleChoi == 2)
            {
                gameOptions(&modified);
            }
            else if (titleChoi == 3)
            {
                exit(1);
            }
            else
            {
                printf("Please enter a different number.\n");
            }
        } while (titleChoi != 1);
    } while (playing != 1);
    return 0;
}